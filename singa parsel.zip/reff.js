var fetch = require('node-fetch');
const fs = require('fs');
const chalk = require('chalk');
const readlineSync = require('readline-sync')
const cluster = require('cluster');
const delay = require('delay');
const { Console } = require('console');
var arguments = require('minimist')(process.argv.slice(2))
var no = 1;

const checkLogin = (phone, password) => new Promise((resolve, reject) => {
        fetch('https://algo-api.lionparcel.com/v2/account/auth/login', {
            method: 'POST',
            headers: {
                'Host': 'algo-api.lionparcel.com',
                'Cache-Control': 'max-age=0',
                'Content-Type': 'application/json; charset=UTF-8',
                'Content-Length': '75',
                'Accept-Encoding': 'gzip, deflate',
                'User-Agent': 'okhttp/5.0.0-alpha.6'
            },
            body: JSON.stringify({
                'password': password,
                'phone_number': phone,
                'role': 'CUSTOMER'
            })
        })

        .then(res => res.text())
        .then(res => resolve(res))
        .catch(err => {
            reject(err)
        })
});

const checkBalance = (bearer) => new Promise((resolve, reject) => {
    fetch('https://algo-api.lionparcel.com/v1/shipment/balance/current', {
    headers: {
        'Host': 'algo-api.lionparcel.com',
        'Authorization': `Bearer ${bearer}`,
        'Cache-Control': 'max-age=0',
        'User-Agent': 'okhttp/5.0.0-alpha.6'
    }
    })

    .then(res => res.text())
    .then(res => resolve(res))
    .catch(err => {
        reject(err)
    })
});

const checkReff = (bearer) => new Promise((resolve, reject) => {
    fetch('https://algo-api.lionparcel.com/v1/account/referral/me/detail', {
        headers: {
            'Host': 'algo-api.lionparcel.com',
            'Authorization': `Bearer ${bearer}`,
            'Cache-Control': 'max-age=0',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'okhttp/5.0.0-alpha.6'
        }
    })

    .then(res => res.text())
    .then(res => resolve(res))
    .catch(err => {
        reject(err)
    })
});


(async () => {
    const read2 = fs.readFileSync('lionParcel.txt', 'UTF-8');
    const list2 = read2.split(/\r?\n/);
    for (var i = 0; i < list2.length; i++) {
        var phone = list2[i].split('|')[0];
        const password = list2[i].split('|')[1];
        var phone = `+62${phone}`;
        console.log(phone)
            const Login = await checkLogin(phone, password);

                try {
                var bearer = Login.match('{"token":"(.*)","type":"');
                var bearer = bearer[1];
                } catch(err) {
                }

                if (bearer) {
                    console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Successfully Login ${phone}|${password}`)
                } else {
                    console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Failure Login`)
                    console.log(Login)
                    continue
                }

            const balance = await checkBalance(bearer);

                try {
                var saldoKu = balance.match('point_total_current_amount":(.*?),"point_near')
                var saldoKu = saldoKu[1];
                } catch(err) {
                }

                if (saldoKu) {
                console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Balance Account : ${saldoKu}`)
                } else {
                console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Balance Account : No Detected`)
                }

            const refferal = await checkReff(bearer);
                var linkRefferal = refferal.match('referral_code":"(.*?)","benefit_header":"')
                var linkRefferal = linkRefferal[1];

                if (linkRefferal) {
                console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Refferal Code   : ${linkRefferal}`)
                } else {
                console.log(chalk.green('[') + chalk.white('!') + chalk.green(']'), `Refferal Code   : Tidak Ditemukan`)
                }

                fs.appendFileSync("checkData.txt", phone + '|' + password + '|' + linkRefferal + '|' + saldoKu + '\n');

                console.log('\n')
    }
})();
